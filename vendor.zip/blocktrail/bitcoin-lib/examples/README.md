These tests are designed to be run on the command line interface. 

