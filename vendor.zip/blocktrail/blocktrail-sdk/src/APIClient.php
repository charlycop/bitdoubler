<?php

namespace Blocktrail\SDK;

/**
 * Class APIClient
 *
 * @deprecated
 * extends BlocktrailSDK for backwards compatibility
 */
class APIClient extends BlocktrailSDK {

}
