<?php

namespace Blocktrail\SDK\Exceptions;

/**
 * Class InvalidCredentials
 *
 */
class BlocktrailSDKException extends \Exception {

}
