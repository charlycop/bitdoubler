<?php

namespace HttpSignatures;

class SignatureParseException extends Exception
{
}
