<?php

namespace HttpSignatures;

class Exception extends \Exception
{
}
