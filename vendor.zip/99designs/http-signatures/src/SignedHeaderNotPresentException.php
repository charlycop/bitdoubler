<?php

namespace HttpSignatures;

class SignedHeaderNotPresentException extends Exception
{
}
