<?php

namespace HttpSignatures;

class KeyStoreException extends Exception
{
}
